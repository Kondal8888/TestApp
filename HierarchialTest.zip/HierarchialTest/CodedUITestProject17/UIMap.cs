﻿namespace CodedUITestProject17
{

    public partial class UIMap
    {
    }
}
